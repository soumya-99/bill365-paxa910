import blurredBlue from "./blurredblue.jpg"
import blurredBlueDark from "./blurredblue-dark.jpg"
import flowerSetting from "./flower_settings.jpg"
import flowerSettingDark from "./flower_settings-dark.jpg"
import flower2 from "./flower-2.png"
import flower2Dark from "./flower-2_dark.png"
import hills from "./hills.jpg"
import hillsDark from "./hills-dark.jpg"
import productHeader from "./productheader.jpg"
import productHeaderDark from "./productheader-dark.jpg"
import flowerHome from "./home_flower.jpg"
import flowerHomeDark from "./home_flower_dark.jpg"
import textureBill from "./texture_bill.jpg"
import textureBillDark from "./texture_bill_dark.jpg"
import blurReport from "./blur_report.jpg"
import blurReportDark from "./blur_report_dark.jpg"
import logo from "./logo_3.png"
import logoDark from "./logo_3-dark.png"

export {
  blurredBlue,
  blurredBlueDark,
  flowerSetting,
  flowerSettingDark,
  flower2,
  flower2Dark,
  hills,
  hillsDark,
  productHeader,
  productHeaderDark,
  flowerHome,
  flowerHomeDark,
  textureBill,
  textureBillDark,
  blurReport,
  blurReportDark,
  logo,
  logoDark
}
